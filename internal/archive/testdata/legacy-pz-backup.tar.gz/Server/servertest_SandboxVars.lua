SandboxVars = {
	Zombies = 3,
}
